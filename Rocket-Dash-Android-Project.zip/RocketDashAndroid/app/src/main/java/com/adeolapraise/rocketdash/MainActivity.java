package com.adeolapraise.rocketdash;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.graphics.*;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.content.Context;
import android.view.MotionEvent;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        setContentView(new GameView(this));
        hideBars();
    }
    private void hideBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c=getWindow().getInsetsController();
            if(c!=null)c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
        } else getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    static class GameView extends View {
        Paint p=new Paint(3); Random r=new Random();
        float rocketX, rocketY, vy; boolean playing=false, gameOver=false, paused=false;
        int score=0, best=0; long last;
        ArrayList<RectF> rocks=new ArrayList<>(); ArrayList<RectF> coins=new ArrayList<>();
        float spawn=0, coinSpawn=0, speed=620;
        android.content.SharedPreferences prefs;
        GameView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); prefs=c.getSharedPreferences("game",0); best=prefs.getInt("best",0); setFocusable(true); }
        void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setTextSize(size);p.setColor(color);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight();
            LinearGradient g=new LinearGradient(0,0,0,h,Color.rgb(12,16,52),Color.rgb(38,17,72),Shader.TileMode.CLAMP); p.setShader(g);c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setColor(Color.argb(35,255,255,255)); for(int i=0;i<35;i++){float x=(i*83)%w,y=(i*137+(System.currentTimeMillis()/40)%h)%h;c.drawCircle(x,y,(i%3)+1,p);}
            if(!playing && !gameOver){ menu(c,w,h); return; }
            if(gameOver){ drawWorld(c,w,h); overlay(c,w,h,"GAME OVER"); return; }
            drawWorld(c,w,h);
            if(paused){overlay(c,w,h,"PAUSED");}
            invalidate();
        }
        void menu(Canvas c,float w,float h){
            text(c,"ROCKET",w/2,h*.30f,54,Color.WHITE,Paint.Align.CENTER); text(c,"DASH",w/2,h*.39f,66,Color.rgb(255,107,53),Paint.Align.CENTER);
            text(c,"Fly • Dodge • Collect • Survive",w/2,h*.47f,18,Color.LTGRAY,Paint.Align.CENTER);
            button(c,w/2,h*.62f,230,68,"PLAY"); text(c,"Best: "+best,w/2,h*.75f,18,Color.WHITE,Paint.Align.CENTER);
        }
        void button(Canvas c,float cx,float cy,float bw,float bh,String s){p.setColor(Color.rgb(255,107,53));c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,28,28,p);text(c,s,cx,cy+11,27,Color.WHITE,Paint.Align.CENTER);}
        void drawWorld(Canvas c,float w,float h){
            // moon
            p.setColor(Color.argb(70,255,255,255));c.drawCircle(w*.82f,h*.18f,34,p);
            // obstacles
            for(RectF q:rocks){p.setColor(Color.rgb(130,80,150));c.drawCircle(q.centerX(),q.centerY(),q.width()/2,p);p.setColor(Color.rgb(177,120,190));c.drawCircle(q.centerX()-q.width()*.15f,q.centerY()-q.height()*.15f,q.width()*.16f,p);}
            for(RectF q:coins){p.setColor(Color.rgb(255,209,102));c.drawCircle(q.centerX(),q.centerY(),q.width()/2,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.rgb(255,239,160));c.drawCircle(q.centerX(),q.centerY(),q.width()/2-3,p);p.setStyle(Paint.Style.FILL);}
            // rocket
            p.setColor(Color.rgb(255,107,53));Path a=new Path();a.moveTo(rocketX,rocketY-34);a.lineTo(rocketX+21,rocketY+25);a.lineTo(rocketX,rocketY+12);a.lineTo(rocketX-21,rocketY+25);a.close();c.drawPath(a,p);
            p.setColor(Color.rgb(76,201,240));c.drawCircle(rocketX,rocketY-3,9,p);
            p.setColor(Color.rgb(255,209,102));Path flame=new Path();flame.moveTo(rocketX-9,rocketY+18);flame.lineTo(rocketX,rocketY+48);flame.lineTo(rocketX+9,rocketY+18);flame.close();c.drawPath(flame,p);
            text(c,"SCORE  "+score,24,42,22,Color.WHITE,Paint.Align.LEFT);text(c,"BEST  "+best,w-24,42,18,Color.LTGRAY,Paint.Align.RIGHT);
            text(c,"PAUSE",w-24,h-24,15,Color.LTGRAY,Paint.Align.RIGHT);
        }
        void overlay(Canvas c,float w,float h,String title){p.setColor(Color.argb(190,5,7,25));c.drawRect(0,0,w,h,p);text(c,title,w/2,h*.38f,44,Color.WHITE,Paint.Align.CENTER);if(gameOver){text(c,"Score: "+score,w/2,h*.47f,22,Color.LTGRAY,Paint.Align.CENTER);button(c,w/2,h*.61f,230,68,"PLAY AGAIN");}else{text(c,"Tap to continue",w/2,h*.48f,20,Color.LTGRAY,Paint.Align.CENTER);}}
        void start(){playing=true;gameOver=false;paused=false;score=0;speed=620;spawn=0;coinSpawn=.5f;rocks.clear();coins.clear();rocketX=getWidth()/2f;rocketY=getHeight()*.72f;vy=0;last=System.nanoTime();invalidate();}
        void update(float dt){if(!playing||paused)return;float w=getWidth(),h=getHeight();
            vy += 1150*dt; rocketY += vy*dt; rocketX=Math.max(28,Math.min(w-28,rocketX));
            if(rocketY<70){rocketY=70;vy=100;} if(rocketY>h-80){gameOver=true;playing=false;save();return;}
            spawn-=dt; coinSpawn-=dt; if(spawn<=0){spawn=Math.max(.42f,1.0f-score/300f);float x=45+r.nextFloat()*(w-90);float size=42+r.nextFloat()*24;rocks.add(new RectF(x-size/2,-size,x+size/2,0));}
            if(coinSpawn<=0){coinSpawn=.8f+r.nextFloat()*.9f;float x=35+r.nextFloat()*(w-70),y=100+r.nextFloat()*(h-220);coins.add(new RectF(x-13,y-13,x+13,y+13));}
            Iterator<RectF> it=rocks.iterator();while(it.hasNext()){RectF q=it.next();q.offset(0,speed*dt);if(q.top>h+60)it.remove();else if(hit(q,rocketX,rocketY,25)){gameOver=true;playing=false;save();return;}}
            it=coins.iterator();while(it.hasNext()){RectF q=it.next();q.offset(0,70*dt);if(q.top>h+30)it.remove();else if(hit(q,rocketX,rocketY,23)){score+=5;it.remove();}}
            score++; speed=620+score*.7f;
        }
        boolean hit(RectF q,float x,float y,float rad){float dx=Math.max(q.left,Math.min(x,q.right))-x,dy=Math.max(q.top,Math.min(y,q.bottom))-y;return dx*dx+dy*dy<rad*rad;}
        void save(){if(score>best){best=score;prefs.edit().putInt("best",best).apply();}}
        final Runnable ticker = new Runnable(){ public void run(){ if(getVisibility()==VISIBLE){ long now=System.nanoTime(); if(last==0) last=now; float dt=Math.min(.033f,(now-last)/1e9f); last=now; update(dt); invalidate(); postDelayed(this,16); } }};
        @Override protected void onAttachedToWindow(){ super.onAttachedToWindow(); post(ticker); }
        @Override protected void onDetachedFromWindow(){ removeCallbacks(ticker); super.onDetachedFromWindow(); }
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN && e.getAction()!=MotionEvent.ACTION_MOVE)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(!playing && !gameOver){if(e.getAction()==MotionEvent.ACTION_DOWN)start();return true;}
            if(gameOver){if(e.getAction()==MotionEvent.ACTION_DOWN)start();return true;}
            if(e.getAction()==MotionEvent.ACTION_DOWN && y>h-70 && x>w-150){paused=!paused;invalidate();return true;}
            if(!paused){rocketX=x; if(e.getAction()==MotionEvent.ACTION_DOWN)vy=-520; invalidate();}
            else if(e.getAction()==MotionEvent.ACTION_DOWN){paused=false;last=System.nanoTime();invalidate();}
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
        @Override protected void onSizeChanged(int w,int h,int ow,int oh){rocketX=w/2f;rocketY=h*.72f;}
    }
}
