# Rocket Dash — Android Play Store Project

A standalone Android version of Rocket Dash. It targets Android 16 / API 36 for the current Google Play new-app requirement.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK 36 if prompted.
3. For a test APK: **Build > Build APK(s)**.
4. For Google Play: **Build > Generate Signed Bundle / APK > Android App Bundle** and create/use your upload key.
5. Upload the resulting `.aab` in Play Console.

## Package
`com.adeolapraise.rocketdash`

## Version
1.0 (versionCode 1)

## Store name
Rocket Dash

## Short description
Fly your rocket, dodge obstacles and collect coins in a fast, fun arcade challenge.

## Full description
Rocket Dash is a simple, fast-paced arcade game built for quick fun. Guide your rocket through the sky, dodge incoming obstacles, collect glowing coins and chase your best score. Every run gets faster, so stay focused and see how long you can survive!

Features:
- One-touch mobile controls
- Increasing challenge
- Coin collection and scoring
- Personal best score saved on the device
- Offline gameplay
- Lightweight and fast
